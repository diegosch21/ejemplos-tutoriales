goog.provide('API.Client.Category');

/**
 * @record
 */
API.Client.Category = function() {}

/**
 * @type {!number}
 * @export
 */
API.Client.Category.prototype.id;

/**
 * @type {!string}
 * @export
 */
API.Client.Category.prototype.name;

