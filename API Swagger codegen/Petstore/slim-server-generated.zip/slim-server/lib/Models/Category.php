<?php
/*
 * Category
 */
namespace \Models;

/*
 * Category
 */
class Category {
    /* @var int $id  */
    private $id;
/* @var string $name  */
    private $name;
}
