<?php
/*
 * Tag
 */
namespace \Models;

/*
 * Tag
 */
class Tag {
    /* @var int $id  */
    private $id;
/* @var string $name  */
    private $name;
}
