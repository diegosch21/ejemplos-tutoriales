Cordova 3.x Tutorial
====================

See http://coenraets.org/blog/cordova-phonegap-3-tutorial/ for instructions.
